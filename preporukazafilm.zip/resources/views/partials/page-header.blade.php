<div class="page-header">
  <h1>{!! $title !!}</h1>
</div>
