{{--
  Template Name: Comming Soon Page Template
--}}

@extends('layouts.app')

@section('content')
  @include('pages.comming-soon.comming-soon')
@endsection
