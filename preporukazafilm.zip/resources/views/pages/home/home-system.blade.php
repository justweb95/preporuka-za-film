<section class="our-system">
  <div class="system-holder container">
    <h3 class="system-heading">Naš AI sistem pokriva:</h3>
    <article class="system-card-holder">
      <span class="system-card">
        <h4 class="card-heading" id="interactive-pf"><strong>5.000</strong>+</h4>
        <p class="card-text">Popularnih filmova</p>
      </span>

      <span class="system-card">
        <h4 class="card-heading" id="interactive-fp"><strong>32</strong>+</h4>
        <p class="card-text">Filmskih platformi</p>
      </span>

      <span class="system-card">
        <h4 class="card-heading" id="interactive-sg"><strong>14.000</strong>+</h4>
        <p class="card-text">Svetskih glumaca</p>
      </span>

      <span class="system-card">
        <h4 class="card-heading" id="interactive-fz"><strong>20</strong>+</h4>
        <p class="card-text">Filmskih žanrova</p>
      </span>
    </article>
  </div>
</section>