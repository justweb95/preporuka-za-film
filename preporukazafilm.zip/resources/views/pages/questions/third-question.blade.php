<article class="question-holder container qa" id="third-question"  style="display: none !important;">
  <h1 class="questionnaire-header">3. Izaberi žanrove koji te zanimaju?</h1>
  <form id="form-holder-2">
      <label for="akcija">
        <input type="checkbox" id="akcija" name="film" value="28">Akcija
      </label>
      <label for="misterija">
        <input type="checkbox" id="misterija" name="film" value="9648">Misterija
      </label>
      <label for="kriminal">
        <input type="checkbox" id="kriminal" name="film" value="80">Kriminal
      </label>
      <label for="komedija">
        <input type="checkbox" id="komedija" name="film" value="35">Komedija
      </label>
      <label for="muzika">
        <input type="checkbox" id="muzika" name="film" value="10402">Muzika
      </label>
      <label for="drama">
        <input type="checkbox" id="drama" name="film" value="18">Drama
      </label>
      <label for="fantastika">
        <input type="checkbox" id="fantastika" name="film" value="14">Fantastika
      </label>
      <label for="sport">
        <input type="checkbox" id="sport" name="film" value="10770">Sport
      </label>
      <label for="avantura">
        <input type="checkbox" id="avantura" name="film" value="12">Avantura
      </label>
      <label for="istorija">
        <input type="checkbox" id="istorija" name="film" value="36">Istorija
      </label>
      <label for="rat">
        <input type="checkbox" id="rat" name="film" value="10752">Rat
      </label>
      <label for="triler">
        <input type="checkbox" id="triler" name="film" value="53">Triler
      </label>
      <label for="animacija">
        <input type="checkbox" id="animacija" name="film" value="16">Animacija
      </label>
      <label for="porodicni">
        <input type="checkbox" id="porodicni" name="film" value="10751">Porodični
      </label>
      <label for="horor">
        <input type="checkbox" id="horor" name="film" value="27">Horor
      </label>
      <label for="vestern">
        <input type="checkbox" id="vestern" name="film" value="37">Vestern
      </label>
      <label for="iznenadi-me">
        <input type="checkbox" id="iznenadi-me" name="film" value="0">Iznenadi me
      </label>
  </form>
  <div class="form-control">
    <button onclick="backQuestion()" class="back-btn">
      <svg width="18" height="14" viewBox="0 0 18 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M17.5 7L2.5 7M2.5 7L8 12.5M2.5 7L8 1.5" stroke="white" stroke-width="2.4"/>
      </svg>  
    Nazad</button>
    <button onclick="nextQuestion()" class="next-btn">
    Dalje
      <svg width="18" height="14" viewBox="0 0 18 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0.5 7L15.5 7M15.5 7L10 1.5M15.5 7L10 12.5" stroke="white" stroke-width="2.4"/>
      </svg>  
    </button>      
  </div>
</article>