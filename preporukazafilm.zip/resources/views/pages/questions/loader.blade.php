{{-- Loader --}}
<article class="question-holder container qa" id="loading">
  <div class="loading-holder">
    <p id="ai-loader" class="ai-loading-text">
      AI Trazi film
    </p>
    <p id="tmdb-loader" class="tmdb-loading-text">
      IMDB Salje Podatke
    </p>
  </div>
</article>
