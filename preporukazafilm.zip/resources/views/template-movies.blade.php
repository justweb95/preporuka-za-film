{{--
  Template Name: All Movies Page Template
--}}

@extends('layouts.app')

@section('content')

  <h2>Movies</h2>


@endsection
