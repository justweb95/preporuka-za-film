{{--
  Template Name: Single Movies Page Template
--}}

@extends('layouts.app')

@section('content')
  @include('pages.single-movie.sm-hero-section')


@endsection
