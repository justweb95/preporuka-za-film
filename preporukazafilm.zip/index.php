<?php

echo view(app('sage.view'), app('sage.data'))->render();
